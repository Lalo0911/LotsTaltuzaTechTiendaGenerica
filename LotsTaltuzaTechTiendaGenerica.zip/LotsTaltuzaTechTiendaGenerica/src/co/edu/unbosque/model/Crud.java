package co.edu.unbosque.model;

public interface Crud {

    public abstract boolean Verificar(String key);

	public abstract String leer();
}
