package co.edu.unbosque.model;

public interface Crud {

	public String leer();
}
