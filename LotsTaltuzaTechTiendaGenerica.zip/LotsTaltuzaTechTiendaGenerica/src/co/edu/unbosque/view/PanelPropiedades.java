package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.*;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PanelPropiedades extends JPanel{

private JLabel labNombreTienda;
	private JTextField txtNombreTienda;
	
	private JLabel labTipoComercio;
	private JTextField txtTipoComercio;
	
	private JLabel labNit;
	private JTextField txtNit;
	
	private JLabel labCiudad;
	private JTextField txtCiudad;
	
	private JLabel labValorIva;
	private JTextField txtValorIva;
	
	private JLabel labTasaInteres;
	private JTextField txtTasaInteres;
	
	private JLabel labNombreBanco;
	private JTextField txtNombreBanco;
	
	private JLabel labNumeroCuenta;
	private JTextField txtNumeroCuenta;
	
	private JLabel labNombreGerente;
	private JTextField txtNombreGerente;
	
	
	private JButton butEditar;
	

	private static final long serialVersionUID = 1L;
	
	public PanelPropiedades() {
		
		setLayout( new GridLayout(14,2) );
		
		TitledBorder border = BorderFactory.createTitledBorder("Juego");
		border.setTitleColor(Color.BLACK);
		setBorder( border );
		
		labNombreTienda = new JLabel("Nombre Tienda:");
		
		
		txtNombreTienda = new JTextField("");
		txtNombreTienda .setForeground(Color.BLACK);
		txtNombreTienda .setBackground(Color.WHITE);
		
		
		labTipoComercio = new JLabel("Tipo comercio:");
		add(labTipoComercio);
		
		txtTipoComercio = new JTextField("");
		txtTipoComercio.setForeground(Color.BLACK);
		txtTipoComercio.setBackground(Color.WHITE);
		add(txtTipoComercio);
		
		labNit = new JLabel("Nit empresa:");
		add(labNit);
		
		txtNit = new JTextField("");
		txtNit.setForeground(Color.BLACK);
		txtNit.setBackground(Color.WHITE);
		add(txtNit);
		
		labCiudad = new JLabel("Ciudad de ubicaci�n:");
		add(labCiudad);
		
		txtCiudad = new JTextField("");
		txtCiudad.setForeground(Color.BLACK);
		txtCiudad.setBackground(Color.WHITE);
		add(txtCiudad);
		
		labValorIva = new JLabel("Valor Iva:");
		add(labValorIva);
		
		txtValorIva = new JTextField("");
		txtValorIva.setForeground(Color.BLACK);
		txtValorIva.setBackground(Color.WHITE);
		add(txtValorIva);
		
		labTasaInteres = new JLabel("Tasa Interes:");
		add(labTasaInteres);
		
		txtTasaInteres = new JTextField("");
		txtTasaInteres.setForeground(Color.BLACK);
		txtTasaInteres.setBackground(Color.WHITE);
		add(txtTasaInteres);
		
		labNombreBanco = new JLabel("Nombre Banco:");
		add(labNombreBanco);
		
		txtNombreBanco = new JTextField("");
		txtNombreBanco.setForeground(Color.BLACK);
		txtNombreBanco.setBackground(Color.WHITE);
		add(txtNombreBanco);
		
		labNumeroCuenta = new JLabel("Numero Cuenta:");
		add(labNumeroCuenta);
		
		txtNumeroCuenta = new JTextField("");
		txtNumeroCuenta.setForeground(Color.BLACK);
		txtNumeroCuenta.setBackground(Color.WHITE);
		add(txtNombreBanco);
		
		labNombreGerente = new JLabel("Nombre Gerente:");
		add(labNombreGerente);
		
		txtNombreGerente = new JTextField("");
		txtNombreGerente.setForeground(Color.BLACK);
		txtNombreGerente.setBackground(Color.WHITE);
		add(txtNombreGerente);
		
		
		butEditar = new JButton("Editar prop");
		butEditar.setActionCommand("EDITARPROPIEDADES");
		add(butEditar);
		
		
		
		add(labNombreTienda);
		add(txtNombreTienda);
			
	
	}
	
}


